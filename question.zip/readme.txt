1、安装
需要安装的库
pip install langchain
pip install chromadb
pip install streamlit
pip install streamlit_chat
pip install pandas
pip install hdbscan

2、程序列表
01emailinfo.ipynb
Email process Ver 2.0 运行程序前将原始csv文件保存在当前目录的Email子目录，合并多个原始的csv格式email文件，删除空列，并按照原始邮件和回复邮件分别保存在不同Questions_data.csv文件和replys_data.csv中，提取对分类有帮助的Subject和Body列合并为Content列，保存在newdata.csv中。

02translate.ipynb
Email translate Version 2.0 读取CSV文件自动进行翻译，这里使用免费百度翻译作为例子，无法实现高速翻译，如需真正使用，需要申请微软，由于后面对email内容利用chatgpt进行摘要缩写，可以要求chatgpt将结果自动输出为英文，因此，本步骤可以省略。

03summary.ipynb
邮件内容提取摘要 Version 2.0 读取CSV文件，对Content生成摘要，已修改为AzureOpenAI调用

04classify.ipynb
Email聚类程序 Version 2.0 读取CSV文件，对Content聚类，并利用chatgpt生成标题，已修改为AzureOpenAI调用

localemb.py
生成知识库，将txt、pdf、csv等文件放入data目录下，运行localemb.py

qa.py
提问测试程序

qa2.py
提问测试程序

customer.py
web版问答程序，运行：python -m streamlit run customer.py



